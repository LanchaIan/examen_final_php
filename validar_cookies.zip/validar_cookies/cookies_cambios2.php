<?php

function comprobar(){
    global $numeroVisitas;
    if (isset($_COOKIE["visita"])) {
        $numeroVisitas = sizeof($_COOKIE["visita"]);
        $numeroVisitas = $numeroVisitas+1;
    }
    else {
        print "<a>lancha</a>";
        $numeroVisitas = 1;
        setcookie("visita[$numeroVisitas]", date('l jS F h:i:s A'), time()+300);
    }

}

function sesiones(){
    if (!isset($_COOKIE["primerinicio"])){
        setcookie("primerinicio", date('l jS F h:i:s A'), time()+300);
    }

    if (!isset($_COOKIE["ultimoinicio"])){
        setcookie("ultimoinicio", date('l jS F h:i:s A'), time()+300);
    }
    comprobar();
}

function crear(){
    global $numeroVisitas;
    session_start();
    $_SESSION["Nombre"] = $_POST["Nombre"]; 
    $fecha_primer_inicio = $_COOKIE["primerinicio"];
    $fecha_ultimo_inicio = $_COOKIE["ultimoinicio"];
    comprobar();
    $numeroVisitas = sizeof($_COOKIE["visita"]);
    echo "<pre>";
    echo "<br>bienvenido: ";
    print_r($_SESSION["Nombre"]);
    echo "<br>";
    echo "Primer inicio de sesión:";
    echo "<a>$fecha_primer_inicio</a>";
    echo "<br>";
    echo "Último inicio de sesión:";
    echo "<a>$fecha_ultimo_inicio</a>";
    echo "<br>";
    echo "num visitas: ";
    echo "<a>$$numeroVisitas</a>";
    echo "</pre>";
    $numeroVisitas = $numeroVisitas+1;
    setcookie("visita[$numeroVisitas]", date('l jS F h:i:s A'), time()+300);  
    setcookie("ultimoinicio", date('l jS F h:i:s A'), time()+300);
}

if (!isset($_POST["Nombre"])){
    sesiones();  
}

if (isset($_POST["Nombre"])){
    sesiones();
    if (isset($_COOKIE["primerinicio"])){
        crear();
    }
    
}
?>

<html>
    <body>
        <form method='post'>
            <label for="cod">Usuario:</label><br>
            <input type="text" id="Nombre" name="Nombre"><br>
            <input type="submit" name="Enviar" value="Enviar"/>
        </form>
    </body>
</html>