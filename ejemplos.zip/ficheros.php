<?php

readfile("texto.txt");

?>

